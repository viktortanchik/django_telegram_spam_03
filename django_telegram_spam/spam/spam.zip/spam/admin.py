from django.contrib import admin
from .models import *

admin.site.register(Subscriber)
admin.site.register(user_settings)
#admin.site.register(Hotel)

class Subscriberadmin (admin.ModelAdmin):
    class Meta:
        model = Subscriber

# class ExampleModeladmin (admin.ModelAdmin):
#     class Meta:
#         model = Hotel
