from django import forms
from .models import *
#from .models import Image
from django.contrib.auth.models import User


# class HotelForm(forms.ModelForm):
#     class Meta:
#         model = Hotel
#         #fields = ['name', 'hotel_Main_Img']
#         exclude = [""]
#
# class ExampleForm(forms.Form):
#     field1 = forms.ChoiceField(required=True, widget=forms.RadioSelect(
#     attrs={'class': 'Radio'}), choices=(('apple','Apple'),('mango','Mango'),))

class SubscriberForm(forms.ModelForm):
    class Meta:
        model = Subscriber
        exclude = [""]
        #fields = ['__all__']
        widgets = {
            'gender': forms.RadioSelect(),

        }
        #'hotel_Main_Img':forms.ImageField()


class SubscriberForm_test(forms.ModelForm):
    class Meta:
        model = user_settings
        exclude = [""]


        #Script_1 = models.ForeignKey(Subscriber_test, on_delete=models.CASCADE, related_name='Script_1', null=True, blank=True)

###########################  USERS   ######################
class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)



class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(label='Password', widget=forms.PasswordInput)
    password2 = forms.CharField(label='Repeat password', widget=forms.PasswordInput)


    class Meta:
        model = User
        fields = ('username', 'first_name', 'email')

    def clean_password2(self):
        cd = self.cleaned_data
        if cd['password'] != cd['password2']:
            raise forms.ValidationError('Passwords don\'t match.')
        return cd['password2']

