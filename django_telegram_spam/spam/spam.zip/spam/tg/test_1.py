import time
print(time.time())