from django.db import models
from django import forms
import time
from django.contrib.auth.models import User
from django.conf import settings
from django.db import models
from django.contrib.auth.models import User



#
# class ExampleModel(models.Model):
#     field1 = forms.ChoiceField(widget=forms.RadioSelect)
# class test_save_img(models.Model):
#     #name = models.CharField(max_length=50)
#     #hotel_Main_Img = models.ImageField(upload_to='images/',blank=False)
#     FUCK_FUCK = models.ImageField(upload_to='images/',blank=False)
#


#

class user_settings(models.Model):
    #user = models.OneToOneField(User, on_delete=models.CASCADE)
    balance = models.CharField(max_length=100,default='test balance')
    wallet = models.CharField(max_length=100,default='test wallet')
    text = models.CharField(max_length=20,default='test TEXT')
    user_names = models.CharField(max_length=20,default='test user_names')
    tarif = models.CharField(max_length=20,default='test tarif')
    nambers = models.CharField(max_length=20,default='test nambers')


class Subscriber(models.Model):
    texts = models.TextField(blank=False)
    TYPE_SELECT = (
        ('0', 'Indonesia account 1'),
        ('1', 'Vietnam account'),
        ('2', 'Indonesia account 2'),
    )
    gender = models.CharField(max_length=20, choices=TYPE_SELECT,default='')
    contact = models.CharField(max_length=128,blank=False)

    Main_Img = models.ImageField(upload_to='images/',blank=False)

    #
    # def __str__(self):
    #     #return f'{[self.adress, self.amount, self.text_mess]!r}'
    #     return f'{[self.texts,self.gender,self.gender,self.contact,self.Main_Img]!r}'


if __name__ == '__main__':
    Subscriber()